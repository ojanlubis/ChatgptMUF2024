'use client';

import { useState, useEffect, useRef } from 'react';
import { useRouter } from 'next/navigation';
import { motion, AnimatePresence } from 'framer-motion';
import { Send, Loader2, AlertCircle, ArrowLeft } from 'lucide-react';
import { useSessionStore } from '@/lib/store';

type Message = {
  id: string;
  role: 'user' | 'assistant';
  content: string;
};

export default function ChatPage() {
  const router = useRouter();
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const {
    sessionId,
    assessmentResult,
    hasPaid,
    messageCount,
    messageLimit,
    incrementMessageCount,
  } = useSessionStore();

  const remainingMessages = messageLimit - messageCount;

  // Auth check
  useEffect(() => {
    if (!hasPaid) {
      router.push('/bayar');
    }
  }, [hasPaid, router]);

  // Scroll to bottom on new messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Initial greeting
  useEffect(() => {
    if (messages.length === 0 && assessmentResult) {
      const greeting: Message = {
        id: 'greeting',
        role: 'assistant',
        content: `Yo, ${assessmentResult.character_match} wannabe! 🍥\n\nGue udah liat hasil assessment lo - ${assessmentResult.ninja_type}, nice! Ada ${remainingMessages} pesan yang bisa lo pake.\n\nMau bahas apa nih? Karir yang cocok? Skill yang perlu diasah? Atau mungkin lo lagi bingung soal sesuatu yang spesifik?\n\nCerita aja, gue dengerin.`,
      };
      setMessages([greeting]);
    }
  }, [assessmentResult, remainingMessages, messages.length]);

  const handleSend = async () => {
    if (!input.trim() || isLoading || remainingMessages <= 0) return;

    const userMessage: Message = {
      id: `user-${Date.now()}`,
      role: 'user',
      content: input.trim(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);
    setError(null);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionId,
          message: userMessage.content,
          history: messages.filter(m => m.id !== 'greeting').map(m => ({
            role: m.role,
            content: m.content,
          })),
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to get response');
      }

      const data = await response.json();

      const assistantMessage: Message = {
        id: `assistant-${Date.now()}`,
        role: 'assistant',
        content: data.response,
      };

      setMessages((prev) => [...prev, assistantMessage]);
      incrementMessageCount();

    } catch (err) {
      console.error('Chat error:', err);
      setError('Gagal mengirim pesan. Coba lagi ya.');
    } finally {
      setIsLoading(false);
      inputRef.current?.focus();
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  if (!hasPaid) {
    return null;
  }

  return (
    <div className="h-screen flex flex-col bg-ninja-black">
      {/* Header */}
      <header className="flex-shrink-0 px-4 py-3 bg-ninja-dark border-b border-ninja-gray">
        <div className="max-w-2xl mx-auto flex items-center justify-between">
          <button
            onClick={() => router.push('/result')}
            className="btn-ghost p-2"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          
          <div className="text-center">
            <div className="font-semibold text-ninja-text">Abang Ninja</div>
            <div className="text-xs text-ninja-text-dim">
              {remainingMessages} pesan tersisa
            </div>
          </div>

          <div className="w-10" /> {/* Spacer */}
        </div>
      </header>

      {/* Messages */}
      <main className="flex-1 overflow-y-auto px-4 py-6">
        <div className="max-w-2xl mx-auto space-y-4">
          <AnimatePresence initial={false}>
            {messages.map((message) => (
              <motion.div
                key={message.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`chat-bubble ${
                    message.role === 'user' 
                      ? 'chat-bubble-user' 
                      : 'chat-bubble-assistant'
                  }`}
                >
                  <p className="whitespace-pre-wrap">{message.content}</p>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>

          {isLoading && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex justify-start"
            >
              <div className="chat-bubble chat-bubble-assistant">
                <div className="flex items-center gap-2">
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span className="text-ninja-text-dim">Lagi mikir...</span>
                </div>
              </div>
            </motion.div>
          )}

          {error && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex justify-center"
            >
              <div className="flex items-center gap-2 text-red-400 text-sm">
                <AlertCircle className="w-4 h-4" />
                {error}
              </div>
            </motion.div>
          )}

          <div ref={messagesEndRef} />
        </div>
      </main>

      {/* Message Limit Warning */}
      {remainingMessages <= 5 && remainingMessages > 0 && (
        <div className="px-4 py-2 bg-ninja-orange/10 text-center">
          <span className="text-ninja-orange text-sm">
            ⚠️ Tinggal {remainingMessages} pesan lagi
          </span>
        </div>
      )}

      {/* Session Ended */}
      {remainingMessages <= 0 && (
        <div className="px-4 py-4 bg-ninja-dark text-center">
          <p className="text-ninja-text-dim mb-3">
            Sesi chat lo udah habis. Makasih udah ngobrol! 🙏
          </p>
          <button
            onClick={() => router.push('/result')}
            className="btn-secondary"
          >
            Kembali ke Hasil
          </button>
        </div>
      )}

      {/* Input */}
      {remainingMessages > 0 && (
        <footer className="flex-shrink-0 px-4 py-4 bg-ninja-dark border-t border-ninja-gray">
          <div className="max-w-2xl mx-auto">
            <div className="flex items-end gap-3">
              <textarea
                ref={inputRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Ketik pesan lo..."
                rows={1}
                className="input flex-1 resize-none max-h-32 py-3"
                style={{
                  height: 'auto',
                  minHeight: '48px',
                }}
                disabled={isLoading}
              />
              <button
                onClick={handleSend}
                disabled={!input.trim() || isLoading}
                className="btn-primary p-3 rounded-xl"
              >
                {isLoading ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  <Send className="w-5 h-5" />
                )}
              </button>
            </div>
          </div>
        </footer>
      )}
    </div>
  );
}
