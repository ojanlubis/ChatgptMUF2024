import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'JalanNinjaku - Temukan Jalan Ninja Karir Lo',
  description: 'AI Career Coach bergaya Naruto. Gratis assessment, cuma Rp 6.969 buat ngobrol lebih lanjut sama Abang Ninja.',
  keywords: ['karir', 'career coach', 'AI', 'fresh graduate', 'Indonesia', 'naruto'],
  authors: [{ name: 'JalanNinjaku' }],
  openGraph: {
    title: 'JalanNinjaku - Temukan Jalan Ninja Karir Lo',
    description: 'AI Career Coach bergaya Naruto. Gratis assessment!',
    url: 'https://jalanninjaku.id',
    siteName: 'JalanNinjaku',
    locale: 'id_ID',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'JalanNinjaku - Temukan Jalan Ninja Karir Lo',
    description: 'AI Career Coach bergaya Naruto. Gratis assessment!',
  },
  viewport: 'width=device-width, initial-scale=1, maximum-scale=1',
  themeColor: '#0A0A0B',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="id">
      <head>
        <link rel="icon" href="/favicon.ico" />
        <link rel="apple-touch-icon" href="/apple-touch-icon.png" />
      </head>
      <body className="antialiased">
        {children}
      </body>
    </html>
  );
}
