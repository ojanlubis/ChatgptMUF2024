'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { motion } from 'framer-motion';
import { 
  Shield, 
  MessageCircle, 
  CheckCircle, 
  Loader2,
  ChevronLeft 
} from 'lucide-react';
import { useSessionStore } from '@/lib/store';

declare global {
  interface Window {
    snap: {
      pay: (token: string, options: {
        onSuccess: (result: any) => void;
        onPending: (result: any) => void;
        onError: (result: any) => void;
        onClose: () => void;
      }) => void;
    };
  }
}

export default function PaymentPage() {
  const router = useRouter();
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const { 
    sessionId, 
    assessmentId, 
    assessmentResult,
    hasPaid,
    setPaid,
  } = useSessionStore();

  // Load Midtrans Snap script
  useEffect(() => {
    const script = document.createElement('script');
    script.src = process.env.NEXT_PUBLIC_MIDTRANS_IS_PRODUCTION === 'true'
      ? 'https://app.midtrans.com/snap/snap.js'
      : 'https://app.sandbox.midtrans.com/snap/snap.js';
    script.setAttribute('data-client-key', process.env.NEXT_PUBLIC_MIDTRANS_CLIENT_KEY || '');
    script.async = true;
    document.body.appendChild(script);

    return () => {
      document.body.removeChild(script);
    };
  }, []);

  // Redirect if already paid
  useEffect(() => {
    if (hasPaid) {
      router.push('/chat');
    }
  }, [hasPaid, router]);

  // Redirect if no assessment
  useEffect(() => {
    if (!assessmentResult) {
      router.push('/assessment');
    }
  }, [assessmentResult, router]);

  const handlePayment = async () => {
    setIsLoading(true);
    setError(null);

    try {
      // Create payment transaction
      const response = await fetch('/api/payment/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionId,
          assessmentId,
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to create payment');
      }

      const { token, orderId } = await response.json();

      // Open Midtrans Snap popup
      window.snap.pay(token, {
        onSuccess: async (result) => {
          console.log('Payment success:', result);
          
          // Update payment status
          await fetch('/api/payment/confirm', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ orderId, status: 'success' }),
          });

          setPaid(orderId);
          router.push('/chat');
        },
        onPending: (result) => {
          console.log('Payment pending:', result);
          setError('Pembayaran pending. Silakan selesaikan pembayaran.');
          setIsLoading(false);
        },
        onError: (result) => {
          console.error('Payment error:', result);
          setError('Pembayaran gagal. Silakan coba lagi.');
          setIsLoading(false);
        },
        onClose: () => {
          console.log('Payment popup closed');
          setIsLoading(false);
        },
      });
    } catch (err) {
      console.error('Payment error:', err);
      setError('Terjadi kesalahan. Silakan coba lagi.');
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-ninja-black">
      {/* Header */}
      <header className="px-4 py-6">
        <div className="max-w-md mx-auto">
          <button
            onClick={() => router.push('/result')}
            className="btn-ghost flex items-center gap-1"
          >
            <ChevronLeft className="w-5 h-5" />
            Kembali
          </button>
        </div>
      </header>

      {/* Content */}
      <main className="px-4 py-8">
        <div className="max-w-md mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-8"
          >
            <h1 className="text-3xl font-bold mb-2">
              Unlock <span className="gradient-text">Chat Session</span>
            </h1>
            <p className="text-ninja-text-dim">
              Ngobrol lebih lanjut sama Abang Ninja
            </p>
          </motion.div>

          {/* Price Card */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="card mb-6"
          >
            <div className="text-center mb-6">
              <div className="text-5xl font-bold text-ninja-orange mb-2">
                Rp 6.969
              </div>
              <div className="text-ninja-text-dim">
                Sekali bayar, bukan subscription
              </div>
            </div>

            {/* Features */}
            <div className="space-y-4">
              {[
                { icon: MessageCircle, text: '25 pesan chat dengan AI' },
                { icon: CheckCircle, text: 'Advice spesifik untuk kondisi lo' },
                { icon: Shield, text: 'Privasi terjaga' },
              ].map((feature, i) => (
                <div key={i} className="flex items-center gap-3">
                  <feature.icon className="w-5 h-5 text-ninja-orange flex-shrink-0" />
                  <span className="text-ninja-text">{feature.text}</span>
                </div>
              ))}
            </div>
          </motion.div>

          {/* Error Message */}
          {error && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="p-4 bg-red-500/10 border border-red-500/30 rounded-xl text-red-400 text-center mb-6"
            >
              {error}
            </motion.div>
          )}

          {/* Pay Button */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            <button
              onClick={handlePayment}
              disabled={isLoading}
              className="btn-primary w-full flex items-center justify-center gap-2 text-lg py-4"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  Processing...
                </>
              ) : (
                <>
                  Bayar Sekarang
                </>
              )}
            </button>
          </motion.div>

          {/* Payment Methods */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
            className="mt-6 text-center"
          >
            <p className="text-ninja-text-dim text-sm mb-3">
              Metode pembayaran
            </p>
            <div className="flex justify-center gap-4 text-ninja-text-dim text-xs">
              <span>QRIS</span>
              <span>•</span>
              <span>GoPay</span>
              <span>•</span>
              <span>OVO</span>
              <span>•</span>
              <span>DANA</span>
            </div>
          </motion.div>

          {/* Security Note */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4 }}
            className="mt-8 p-4 bg-ninja-gray/50 rounded-xl text-center"
          >
            <Shield className="w-6 h-6 text-ninja-text-dim mx-auto mb-2" />
            <p className="text-ninja-text-dim text-sm">
              Pembayaran aman via Midtrans.
              <br />
              Data lo ga disimpan di server kami.
            </p>
          </motion.div>
        </div>
      </main>
    </div>
  );
}
