'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, ChevronRight, Loader2 } from 'lucide-react';
import { useSessionStore } from '@/lib/store';
import { assessmentQuestions, formatAnswersForAnalysis } from '@/lib/questions';

export default function AssessmentPage() {
  const router = useRouter();
  const {
    currentQuestion,
    answers,
    setAnswer,
    nextQuestion,
    prevQuestion,
    sessionId,
    initSession,
  } = useSessionStore();

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [textAnswer, setTextAnswer] = useState('');
  const [sliderValue, setSliderValue] = useState(3);

  const question = assessmentQuestions[currentQuestion - 1];
  const currentAnswer = answers[currentQuestion];
  const progress = (currentQuestion / assessmentQuestions.length) * 100;
  const isLastQuestion = currentQuestion === assessmentQuestions.length;
  const canProceed = currentAnswer !== undefined || 
    (question.type === 'text' && textAnswer.trim().length > 0) ||
    (question.type === 'scale');

  useEffect(() => {
    initSession();
  }, [initSession]);

  // Sync text answer with store
  useEffect(() => {
    if (question.type === 'text' && typeof currentAnswer === 'string') {
      setTextAnswer(currentAnswer);
    } else if (question.type === 'text') {
      setTextAnswer('');
    }
  }, [currentQuestion, currentAnswer, question.type]);

  // Sync slider with store
  useEffect(() => {
    if (question.type === 'scale' && typeof currentAnswer === 'number') {
      setSliderValue(currentAnswer);
    } else if (question.type === 'scale') {
      setSliderValue(3);
    }
  }, [currentQuestion, currentAnswer, question.type]);

  const handleNext = async () => {
    // Save text/scale answer first
    if (question.type === 'text') {
      setAnswer(currentQuestion, textAnswer);
    } else if (question.type === 'scale') {
      setAnswer(currentQuestion, sliderValue);
    }

    if (isLastQuestion) {
      setIsSubmitting(true);
      try {
        // Get final answers
        const finalAnswers = {
          ...answers,
          [currentQuestion]: question.type === 'text' ? textAnswer : 
                            question.type === 'scale' ? sliderValue : 
                            answers[currentQuestion],
        };

        // Submit to API
        const response = await fetch('/api/assessment/submit', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            sessionId,
            answers: finalAnswers,
          }),
        });

        if (!response.ok) throw new Error('Failed to submit');

        const data = await response.json();
        
        // Store assessment ID and redirect
        useSessionStore.getState().setAssessmentId(data.assessmentId);
        useSessionStore.getState().setAssessmentResult(data.result);
        useSessionStore.getState().completeAssessment();
        
        router.push('/result');
      } catch (error) {
        console.error('Submit error:', error);
        setIsSubmitting(false);
        // TODO: Show error toast
      }
    } else {
      nextQuestion();
    }
  };

  const handleOptionSelect = (value: string) => {
    setAnswer(currentQuestion, value);
  };

  return (
    <div className="min-h-screen bg-ninja-black flex flex-col">
      {/* Progress Bar */}
      <div className="fixed top-0 left-0 right-0 z-50">
        <div className="progress-bar">
          <div 
            className="progress-bar-fill"
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>

      {/* Header */}
      <header className="px-4 py-6">
        <div className="max-w-2xl mx-auto flex items-center justify-between">
          <button
            onClick={() => currentQuestion > 1 ? prevQuestion() : router.push('/')}
            className="btn-ghost flex items-center gap-1"
          >
            <ChevronLeft className="w-5 h-5" />
            {currentQuestion > 1 ? 'Back' : 'Home'}
          </button>
          <span className="text-ninja-text-dim text-sm">
            {currentQuestion} / {assessmentQuestions.length}
          </span>
        </div>
      </header>

      {/* Question Content */}
      <main className="flex-1 px-4 py-8 flex items-center">
        <div className="max-w-2xl mx-auto w-full">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentQuestion}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3 }}
            >
              {/* Question */}
              <h1 className="text-2xl md:text-3xl font-bold mb-2">
                {question.question}
              </h1>
              {question.subtitle && (
                <p className="text-ninja-text-dim mb-8">
                  {question.subtitle}
                </p>
              )}

              {/* Answer Options */}
              <div className="space-y-3 mt-8">
                {question.type === 'choice' && question.options?.map((option) => (
                  <button
                    key={option.value}
                    onClick={() => handleOptionSelect(option.value)}
                    className={`option-card w-full text-left flex items-center gap-4 ${
                      currentAnswer === option.value ? 'selected' : ''
                    }`}
                  >
                    {option.emoji && (
                      <span className="text-2xl">{option.emoji}</span>
                    )}
                    <span className="text-lg">{option.label}</span>
                  </button>
                ))}

                {question.type === 'scale' && question.scaleLabels && (
                  <div className="py-8">
                    <input
                      type="range"
                      min="1"
                      max="5"
                      value={sliderValue}
                      onChange={(e) => setSliderValue(Number(e.target.value))}
                      className="w-full h-2 bg-ninja-gray rounded-lg appearance-none cursor-pointer accent-ninja-orange"
                    />
                    <div className="flex justify-between mt-4 text-sm">
                      <span className="text-ninja-text-dim max-w-[40%]">
                        {question.scaleLabels.left}
                      </span>
                      <span className="text-ninja-text-dim max-w-[40%] text-right">
                        {question.scaleLabels.right}
                      </span>
                    </div>
                  </div>
                )}

                {question.type === 'text' && (
                  <textarea
                    value={textAnswer}
                    onChange={(e) => setTextAnswer(e.target.value)}
                    placeholder="Cerita aja, ga usah formal..."
                    className="input min-h-[150px] resize-none"
                    maxLength={500}
                  />
                )}
              </div>
            </motion.div>
          </AnimatePresence>
        </div>
      </main>

      {/* Footer with Next Button */}
      <footer className="px-4 py-6 bg-ninja-dark/50">
        <div className="max-w-2xl mx-auto">
          <button
            onClick={handleNext}
            disabled={!canProceed || isSubmitting}
            className="btn-primary w-full flex items-center justify-center gap-2"
          >
            {isSubmitting ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                Analyzing...
              </>
            ) : isLastQuestion ? (
              <>
                Lihat Hasil
                <ChevronRight className="w-5 h-5" />
              </>
            ) : (
              <>
                Lanjut
                <ChevronRight className="w-5 h-5" />
              </>
            )}
          </button>
        </div>
      </footer>
    </div>
  );
}
