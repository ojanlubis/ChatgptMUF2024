'use client';

import { useEffect } from 'react';
import Link from 'next/link';
import { motion } from 'framer-motion';
import { Zap, MessageCircle, Target, TrendingUp, ChevronRight } from 'lucide-react';
import { useSessionStore } from '@/lib/store';

export default function LandingPage() {
  const initSession = useSessionStore((s) => s.initSession);

  useEffect(() => {
    initSession();
  }, [initSession]);

  return (
    <div className="min-h-screen landing-bg">
      {/* Hero Section */}
      <section className="relative px-4 pt-12 pb-20 md:pt-20 md:pb-32">
        <div className="max-w-4xl mx-auto text-center">
          {/* Badge */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="inline-flex items-center gap-2 px-4 py-2 bg-ninja-gray rounded-full text-sm text-ninja-text-dim mb-8"
          >
            <span className="w-2 h-2 bg-ninja-orange rounded-full animate-pulse" />
            AI Career Coach pertama yang ngomong bahasa lo
          </motion.div>

          {/* Main Headline */}
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-4xl md:text-6xl lg:text-7xl font-bold mb-6 leading-tight"
          >
            Bingung Mau{' '}
            <span className="gradient-text">Kerja Apa?</span>
            <br />
            <span className="text-ninja-text-dim text-3xl md:text-5xl lg:text-6xl">
              Kita cari jalan ninja lo bareng-bareng.
            </span>
          </motion.h1>

          {/* Subheadline */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="text-lg md:text-xl text-ninja-text-dim mb-10 max-w-2xl mx-auto"
          >
            Assessment gratis 5 menit → Dapet insight karir yang cocok buat lo → 
            Mau ngobrol lebih lanjut? Cuma <span className="text-ninja-orange font-semibold">Rp 6.969</span> 
            {' '}(lebih murah dari kopi susu).
          </motion.p>

          {/* CTA Button */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
          >
            <Link
              href="/assessment"
              className="group inline-flex items-center gap-3 btn-primary text-lg px-8 py-4 glow-orange animate-pulse-orange"
            >
              Mulai Assessment Gratis
              <ChevronRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </Link>
            <p className="text-ninja-text-dim text-sm mt-4">
              ✨ 10 pertanyaan • 5 menit • 100% gratis
            </p>
          </motion.div>
        </div>

        {/* Floating elements for visual interest */}
        <div className="absolute top-1/4 left-10 w-20 h-20 bg-ninja-orange/10 rounded-full blur-xl animate-float" />
        <div className="absolute bottom-1/4 right-10 w-32 h-32 bg-ninja-orange/5 rounded-full blur-2xl animate-float" style={{ animationDelay: '1s' }} />
      </section>

      {/* How It Works */}
      <section className="px-4 py-20 bg-ninja-dark/50">
        <div className="max-w-5xl mx-auto">
          <motion.h2
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="text-2xl md:text-3xl font-bold text-center mb-12"
          >
            Gimana Caranya?
          </motion.h2>

          <div className="grid md:grid-cols-3 gap-6">
            {[
              {
                icon: Target,
                title: '1. Assessment',
                desc: 'Jawab 10 pertanyaan tentang lo. Ga ada yang salah, santai aja.',
                color: 'text-rank-genin',
              },
              {
                icon: Zap,
                title: '2. Dapet Hasil',
                desc: 'AI bakal analyze dan kasih tau tipe ninja + rekomendasi karir yang cocok.',
                color: 'text-rank-chunin',
              },
              {
                icon: MessageCircle,
                title: '3. Ngobrol',
                desc: 'Pengen explore lebih? Chat sama Abang Ninja cuma Rp 6.969.',
                color: 'text-ninja-orange',
              },
            ].map((step, i) => (
              <motion.div
                key={step.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="card hover:border-ninja-gray-light transition-colors"
              >
                <step.icon className={`w-10 h-10 ${step.color} mb-4`} />
                <h3 className="text-xl font-semibold mb-2">{step.title}</h3>
                <p className="text-ninja-text-dim">{step.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Social Proof / Why This Works */}
      <section className="px-4 py-20">
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="card bg-gradient-to-br from-ninja-gray to-ninja-dark border-ninja-gray-light"
          >
            <div className="text-center mb-8">
              <h2 className="text-2xl md:text-3xl font-bold mb-4">
                Kenapa Career Coach Mahal?
              </h2>
              <p className="text-ninja-text-dim max-w-2xl mx-auto">
                Career coach manusia = Rp 800rb - 3 juta per sesi. 
                Tes psikologi online = Bahasa Inggris, kaku, ga actionable.
                <br /><br />
                <span className="text-ninja-text">
                  Lo butuh sesuatu yang <span className="text-ninja-orange">paham konteks Indonesia</span>, 
                  {' '}<span className="text-ninja-orange">ngomong bahasa lo</span>, 
                  dan <span className="text-ninja-orange">affordable</span>.
                </span>
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              <div className="p-4 bg-ninja-black/50 rounded-xl">
                <div className="text-3xl font-bold text-ninja-orange mb-2">5 menit</div>
                <div className="text-ninja-text-dim">Assessment yang ga bikin ngantuk</div>
              </div>
              <div className="p-4 bg-ninja-black/50 rounded-xl">
                <div className="text-3xl font-bold text-ninja-orange mb-2">Rp 6.969</div>
                <div className="text-ninja-text-dim">Lebih murah dari kopi fancy</div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Rank System Preview */}
      <section className="px-4 py-20 bg-ninja-dark/50">
        <div className="max-w-4xl mx-auto text-center">
          <motion.h2
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="text-2xl md:text-3xl font-bold mb-4"
          >
            Lo Termasuk Rank Apa?
          </motion.h2>
          <p className="text-ninja-text-dim mb-10">
            Setiap shinobi punya level masing-masing. Yang penting tau dimana posisi lo sekarang.
          </p>

          <div className="flex flex-wrap justify-center gap-4">
            {[
              { rank: 'Genin', color: 'rank-genin', desc: 'Baru mulai explore' },
              { rank: 'Chunin', color: 'rank-chunin', desc: 'Punya arah, butuh skill' },
              { rank: 'Jonin', color: 'rank-jonin', desc: 'Experienced, siap tantangan' },
              { rank: 'Hokage', color: 'rank-hokage', desc: 'Master, bisa lead' },
            ].map((r, i) => (
              <motion.div
                key={r.rank}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className={`rank-badge ${r.color} px-6 py-3`}
              >
                <div className="font-semibold">{r.rank}</div>
                <div className="text-xs opacity-80 ml-2">{r.desc}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="px-4 py-20">
        <div className="max-w-2xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              Siap Cari Jalan Ninja Lo?
            </h2>
            <p className="text-ninja-text-dim mb-8">
              "Menjadi Hokage adalah impian gue!" — Tapi lo harus tau dulu lo cocoknya jadi apa.
            </p>
            <Link
              href="/assessment"
              className="group inline-flex items-center gap-3 btn-primary text-lg px-8 py-4"
            >
              Mulai Sekarang — Gratis
              <ChevronRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="px-4 py-8 border-t border-ninja-gray">
        <div className="max-w-4xl mx-auto text-center text-ninja-text-dim text-sm">
          <p className="mb-2">
            <span className="text-ninja-orange">JalanNinjaku.id</span> — AI Career Coach untuk Shinobi Indonesia
          </p>
          <p>
            Dibuat dengan ❤️ dan banyak ramen
          </p>
        </div>
      </footer>
    </div>
  );
}
