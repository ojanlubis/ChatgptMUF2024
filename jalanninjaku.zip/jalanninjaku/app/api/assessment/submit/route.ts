import { NextRequest, NextResponse } from 'next/server';
import { createServerClient } from '@/lib/supabase';
import { analyzeAssessment, type AssessmentResult } from '@/lib/claude';
import { formatAnswersForAnalysis } from '@/lib/questions';
import { nanoid } from 'nanoid';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { sessionId, answers } = body;

    if (!sessionId || !answers) {
      return NextResponse.json(
        { error: 'Missing sessionId or answers' },
        { status: 400 }
      );
    }

    const supabase = createServerClient();

    // 1. Get or create user
    let { data: user } = await supabase
      .from('users')
      .select('id')
      .eq('session_id', sessionId)
      .single();

    if (!user) {
      const { data: newUser, error: userError } = await supabase
        .from('users')
        .insert({ session_id: sessionId })
        .select('id')
        .single();

      if (userError) throw userError;
      user = newUser;
    }

    // 2. Format answers for Claude
    const formattedAnswers = formatAnswersForAnalysis(answers);

    // 3. Analyze with Claude
    let result: AssessmentResult;
    try {
      result = await analyzeAssessment(formattedAnswers);
    } catch (aiError) {
      console.error('AI analysis error:', aiError);
      // Fallback result if AI fails
      result = {
        ninja_type: 'The Explorer',
        ninja_rank: 'Genin',
        character_match: 'Naruto',
        personality_summary: 'Lo lagi di fase exploration - masih nyari jalan ninja yang paling cocok. Ini bagus! Artinya lo open-minded dan ga takut coba hal baru.',
        strengths: ['Curious', 'Adaptable', 'Open-minded'],
        career_matches: [
          { title: 'Product Manager', fit: 'Cocok buat yang suka explore berbagai bidang' },
          { title: 'Business Development', fit: 'Butuh orang yang adaptable' },
          { title: 'Content Creator', fit: 'Bisa channel curiosity lo' },
          { title: 'Consultant', fit: 'Setiap project beda, ga boring' },
        ],
        growth_area: 'Focus - coba commit ke satu arah dulu sebelum pivot',
      };
    }

    // 4. Save assessment to database
    const { data: assessment, error: assessmentError } = await supabase
      .from('assessments')
      .insert({
        user_id: user.id,
        answers: answers,
        ninja_type: result.ninja_type,
        ninja_rank: result.ninja_rank,
        character_match: result.character_match,
        personality_summary: result.personality_summary,
        strengths: result.strengths,
        career_matches: result.career_matches,
        growth_area: result.growth_area,
        completed_at: new Date().toISOString(),
      })
      .select('id')
      .single();

    if (assessmentError) throw assessmentError;

    // 5. Track analytics event
    await supabase.from('analytics_events').insert({
      user_id: user.id,
      event_name: 'assessment_completed',
      event_data: {
        ninja_type: result.ninja_type,
        ninja_rank: result.ninja_rank,
        character_match: result.character_match,
      },
    });

    return NextResponse.json({
      success: true,
      assessmentId: assessment.id,
      result,
    });

  } catch (error) {
    console.error('Assessment submit error:', error);
    return NextResponse.json(
      { error: 'Failed to process assessment' },
      { status: 500 }
    );
  }
}
