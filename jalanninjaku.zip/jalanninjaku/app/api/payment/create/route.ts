import { NextRequest, NextResponse } from 'next/server';
import { createServerClient } from '@/lib/supabase';
import { nanoid } from 'nanoid';
import midtransClient from 'midtrans-client';

// Initialize Midtrans Snap
const snap = new midtransClient.Snap({
  isProduction: process.env.MIDTRANS_IS_PRODUCTION === 'true',
  serverKey: process.env.MIDTRANS_SERVER_KEY || '',
});

const PRICE_IDR = Number(process.env.NEXT_PUBLIC_PRICE_IDR) || 6969;

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { sessionId, assessmentId } = body;

    if (!sessionId) {
      return NextResponse.json(
        { error: 'Missing sessionId' },
        { status: 400 }
      );
    }

    const supabase = createServerClient();

    // Get user
    const { data: user } = await supabase
      .from('users')
      .select('id')
      .eq('session_id', sessionId)
      .single();

    if (!user) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      );
    }

    // Generate unique order ID
    const orderId = `JNK-${Date.now()}-${nanoid(6)}`;

    // Create Midtrans transaction
    const parameter = {
      transaction_details: {
        order_id: orderId,
        gross_amount: PRICE_IDR,
      },
      item_details: [
        {
          id: 'chat-session',
          price: PRICE_IDR,
          quantity: 1,
          name: 'Chat Session - JalanNinjaku',
        },
      ],
      customer_details: {
        first_name: 'Shinobi',
        email: `${sessionId.slice(0, 8)}@jalanninjaku.id`,
      },
      callbacks: {
        finish: `${process.env.NEXT_PUBLIC_APP_URL}/chat`,
      },
    };

    const transaction = await snap.createTransaction(parameter);

    // Save payment record
    await supabase.from('payments').insert({
      user_id: user.id,
      assessment_id: assessmentId || null,
      order_id: orderId,
      gross_amount: PRICE_IDR,
      status: 'pending',
    });

    // Track analytics
    await supabase.from('analytics_events').insert({
      user_id: user.id,
      event_name: 'payment_initiated',
      event_data: { order_id: orderId, amount: PRICE_IDR },
    });

    return NextResponse.json({
      token: transaction.token,
      orderId,
    });

  } catch (error) {
    console.error('Payment create error:', error);
    return NextResponse.json(
      { error: 'Failed to create payment' },
      { status: 500 }
    );
  }
}
