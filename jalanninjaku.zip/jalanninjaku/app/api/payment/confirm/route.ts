import { NextRequest, NextResponse } from 'next/server';
import { createServerClient } from '@/lib/supabase';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { orderId, status } = body;

    if (!orderId || !status) {
      return NextResponse.json(
        { error: 'Missing orderId or status' },
        { status: 400 }
      );
    }

    const supabase = createServerClient();

    // Update payment status
    const { data: payment, error } = await supabase
      .from('payments')
      .update({
        status: status === 'success' ? 'success' : status,
        paid_at: status === 'success' ? new Date().toISOString() : null,
      })
      .eq('order_id', orderId)
      .select('id, user_id, assessment_id')
      .single();

    if (error) throw error;

    // If payment successful, create chat session
    if (status === 'success' && payment) {
      const { data: chatSession } = await supabase
        .from('chat_sessions')
        .insert({
          user_id: payment.user_id,
          assessment_id: payment.assessment_id,
          payment_id: payment.id,
          message_limit: 25,
        })
        .select('id')
        .single();

      // Track analytics
      await supabase.from('analytics_events').insert({
        user_id: payment.user_id,
        event_name: 'payment_success',
        event_data: { order_id: orderId },
      });

      return NextResponse.json({
        success: true,
        chatSessionId: chatSession?.id,
      });
    }

    return NextResponse.json({ success: true });

  } catch (error) {
    console.error('Payment confirm error:', error);
    return NextResponse.json(
      { error: 'Failed to confirm payment' },
      { status: 500 }
    );
  }
}
