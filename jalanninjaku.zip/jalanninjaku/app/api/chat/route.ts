import { NextRequest, NextResponse } from 'next/server';
import { createServerClient } from '@/lib/supabase';
import { chat, type ChatMessage } from '@/lib/claude';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { sessionId, message, history } = body;

    if (!sessionId || !message) {
      return NextResponse.json(
        { error: 'Missing sessionId or message' },
        { status: 400 }
      );
    }

    const supabase = createServerClient();

    // Get user and verify they have paid
    const { data: user } = await supabase
      .from('users')
      .select('id')
      .eq('session_id', sessionId)
      .single();

    if (!user) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      );
    }

    // Check for active paid chat session
    const { data: chatSession } = await supabase
      .from('chat_sessions')
      .select('id, message_count, message_limit, assessment_id')
      .eq('user_id', user.id)
      .eq('is_active', true)
      .single();

    if (!chatSession) {
      return NextResponse.json(
        { error: 'No active chat session' },
        { status: 403 }
      );
    }

    // Check message limit
    if (chatSession.message_count >= chatSession.message_limit) {
      return NextResponse.json(
        { error: 'Message limit reached' },
        { status: 403 }
      );
    }

    // Get assessment result for context
    let assessmentContext = null;
    if (chatSession.assessment_id) {
      const { data: assessment } = await supabase
        .from('assessments')
        .select('ninja_type, character_match, strengths, career_matches, growth_area')
        .eq('id', chatSession.assessment_id)
        .single();

      if (assessment) {
        assessmentContext = assessment;
      }
    }

    // Prepare messages for Claude
    const messages: ChatMessage[] = [
      ...(history || []),
      { role: 'user' as const, content: message },
    ];

    // Call Claude
    const { response, tokensUsed } = await chat(messages, assessmentContext);

    // Save messages to database
    await supabase.from('chat_messages').insert([
      {
        session_id: chatSession.id,
        role: 'user',
        content: message,
      },
      {
        session_id: chatSession.id,
        role: 'assistant',
        content: response,
        tokens_used: tokensUsed,
      },
    ]);

    // Increment message count
    await supabase
      .from('chat_sessions')
      .update({ message_count: chatSession.message_count + 1 })
      .eq('id', chatSession.id);

    // Track analytics
    await supabase.from('analytics_events').insert({
      user_id: user.id,
      event_name: 'chat_message_sent',
      event_data: { 
        message_number: chatSession.message_count + 1,
        tokens_used: tokensUsed,
      },
    });

    return NextResponse.json({
      response,
      remainingMessages: chatSession.message_limit - chatSession.message_count - 1,
    });

  } catch (error) {
    console.error('Chat error:', error);
    return NextResponse.json(
      { error: 'Failed to process message' },
      { status: 500 }
    );
  }
}
