import { NextRequest, NextResponse } from 'next/server';
import { createServerClient } from '@/lib/supabase';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { event, data, sessionId } = body;

    if (!event) {
      return NextResponse.json(
        { error: 'Missing event name' },
        { status: 400 }
      );
    }

    const supabase = createServerClient();

    // Get user if sessionId provided
    let userId = null;
    if (sessionId) {
      const { data: user } = await supabase
        .from('users')
        .select('id')
        .eq('session_id', sessionId)
        .single();
      
      if (user) {
        userId = user.id;
      }
    }

    // Track event
    await supabase.from('analytics_events').insert({
      user_id: userId,
      event_name: event,
      event_data: data || {},
      page_url: request.headers.get('referer') || null,
      user_agent: request.headers.get('user-agent') || null,
    });

    return NextResponse.json({ success: true });

  } catch (error) {
    console.error('Analytics track error:', error);
    // Don't fail the request for analytics errors
    return NextResponse.json({ success: false });
  }
}
