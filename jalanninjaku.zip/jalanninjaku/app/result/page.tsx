'use client';

import { useEffect, useRef, useState } from 'react';
import { useRouter } from 'next/navigation';
import { motion } from 'framer-motion';
import { 
  Share2, 
  MessageCircle, 
  Download, 
  ChevronRight,
  Sparkles,
  Target,
  TrendingUp,
  Zap
} from 'lucide-react';
import { useSessionStore } from '@/lib/store';
import { toPng } from 'html-to-image';

// Ninja character data
const characterData: Record<string, { emoji: string; quote: string }> = {
  'Naruto': { emoji: '🍥', quote: 'Ga ada yang mustahil kalau lo percaya!' },
  'Sasuke': { emoji: '⚡', quote: 'Jadi yang terbaik butuh fokus dan dedikasi.' },
  'Sakura': { emoji: '🌸', quote: 'Strength bukan cuma soal power, tapi juga wisdom.' },
  'Shikamaru': { emoji: '☁️', quote: 'Kerja smart > kerja keras doang.' },
  'Rock Lee': { emoji: '💪', quote: 'Hard work beats talent when talent doesn\'t work hard!' },
  'Hinata': { emoji: '👁️', quote: 'Quiet confidence bisa bawa lo jauh.' },
  'Kakashi': { emoji: '📖', quote: 'Experience is the best teacher.' },
  'Itachi': { emoji: '🌙', quote: 'Think long-term, sacrifice short-term.' },
};

const rankColors: Record<string, string> = {
  'Genin': 'rank-genin',
  'Chunin': 'rank-chunin',
  'Jonin': 'rank-jonin',
  'Hokage': 'rank-hokage',
};

export default function ResultPage() {
  const router = useRouter();
  const resultCardRef = useRef<HTMLDivElement>(null);
  const [isSharing, setIsSharing] = useState(false);

  const { assessmentResult, isAssessmentComplete, hasPaid } = useSessionStore();

  // Redirect if no result
  useEffect(() => {
    if (!isAssessmentComplete || !assessmentResult) {
      router.push('/assessment');
    }
  }, [isAssessmentComplete, assessmentResult, router]);

  if (!assessmentResult) {
    return null;
  }

  const character = characterData[assessmentResult.character_match] || characterData['Naruto'];
  const rankClass = rankColors[assessmentResult.ninja_rank] || 'rank-genin';

  const handleShare = async () => {
    setIsSharing(true);
    
    try {
      if (resultCardRef.current) {
        const dataUrl = await toPng(resultCardRef.current, {
          quality: 0.95,
          backgroundColor: '#0A0A0B',
        });

        // Try native share first (mobile)
        if (navigator.share && navigator.canShare) {
          const blob = await (await fetch(dataUrl)).blob();
          const file = new File([blob], 'jalan-ninja-ku.png', { type: 'image/png' });
          
          if (navigator.canShare({ files: [file] })) {
            await navigator.share({
              title: 'Hasil Jalan Ninja Gue',
              text: `Gue ternyata tipe ${assessmentResult.ninja_type}! Cek jalan ninja lo di jalanninjaku.id`,
              files: [file],
            });
          }
        } else {
          // Fallback: download image
          const link = document.createElement('a');
          link.download = 'jalan-ninja-ku.png';
          link.href = dataUrl;
          link.click();
        }
      }

      // Track share event
      await fetch('/api/analytics/track', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ event: 'result_shared' }),
      });

    } catch (error) {
      console.error('Share error:', error);
    } finally {
      setIsSharing(false);
    }
  };

  const handleContinueChat = () => {
    if (hasPaid) {
      router.push('/chat');
    } else {
      router.push('/bayar');
    }
  };

  return (
    <div className="min-h-screen bg-ninja-black">
      {/* Header */}
      <header className="px-4 py-6 text-center">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-ninja-orange text-sm font-medium"
        >
          ✨ Assessment Complete
        </motion.div>
      </header>

      {/* Result Card (Shareable) */}
      <section className="px-4 pb-8">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
          ref={resultCardRef}
          className="max-w-md mx-auto result-card-shareable"
        >
          {/* Character & Type */}
          <div className="text-center mb-6">
            <div className="text-6xl mb-4">{character.emoji}</div>
            <h1 className="text-3xl font-bold gradient-text mb-2">
              {assessmentResult.ninja_type}
            </h1>
            <p className="text-ninja-text-dim">
              Mirip kayak <span className="text-ninja-orange">{assessmentResult.character_match}</span>
            </p>
          </div>

          {/* Rank Badge */}
          <div className="flex justify-center mb-6">
            <span className={`rank-badge ${rankClass} text-lg px-6 py-2`}>
              Rank: {assessmentResult.ninja_rank}
            </span>
          </div>

          {/* Strengths */}
          <div className="flex flex-wrap justify-center gap-2 mb-6">
            {assessmentResult.strengths.map((strength, i) => (
              <span
                key={i}
                className="px-3 py-1 bg-ninja-black/50 rounded-full text-sm text-ninja-text"
              >
                {strength}
              </span>
            ))}
          </div>

          {/* Quote */}
          <p className="text-center text-ninja-text-dim italic text-sm">
            "{character.quote}"
          </p>

          {/* Branding */}
          <div className="text-center mt-6 pt-4 border-t border-ninja-gray">
            <span className="text-ninja-orange font-semibold text-sm">
              jalanninjaku.id
            </span>
          </div>
        </motion.div>
      </section>

      {/* Share Button */}
      <section className="px-4 pb-8">
        <div className="max-w-md mx-auto">
          <button
            onClick={handleShare}
            disabled={isSharing}
            className="btn-secondary w-full flex items-center justify-center gap-2"
          >
            <Share2 className="w-5 h-5" />
            {isSharing ? 'Preparing...' : 'Share Hasil Lo'}
          </button>
        </div>
      </section>

      {/* Detailed Results */}
      <section className="px-4 py-8 bg-ninja-dark/50">
        <div className="max-w-2xl mx-auto space-y-8">
          {/* Personality Summary */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="card"
          >
            <div className="flex items-center gap-3 mb-4">
              <Sparkles className="w-6 h-6 text-ninja-orange" />
              <h2 className="text-xl font-semibold">Tentang Lo</h2>
            </div>
            <p className="text-ninja-text-dim leading-relaxed whitespace-pre-line">
              {assessmentResult.personality_summary}
            </p>
          </motion.div>

          {/* Career Matches */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="card"
          >
            <div className="flex items-center gap-3 mb-4">
              <Target className="w-6 h-6 text-ninja-orange" />
              <h2 className="text-xl font-semibold">Karir yang Cocok</h2>
            </div>
            <div className="space-y-4">
              {assessmentResult.career_matches.map((career, i) => (
                <div
                  key={i}
                  className="p-4 bg-ninja-black/50 rounded-xl"
                >
                  <div className="font-semibold text-ninja-text mb-1">
                    {career.title}
                  </div>
                  <div className="text-sm text-ninja-text-dim">
                    {career.fit}
                  </div>
                </div>
              ))}
            </div>
          </motion.div>

          {/* Growth Area */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="card"
          >
            <div className="flex items-center gap-3 mb-4">
              <TrendingUp className="w-6 h-6 text-ninja-orange" />
              <h2 className="text-xl font-semibold">Area Pengembangan</h2>
            </div>
            <p className="text-ninja-text-dim">
              {assessmentResult.growth_area}
            </p>
          </motion.div>
        </div>
      </section>

      {/* CTA: Continue to Chat */}
      <section className="px-4 py-12">
        <div className="max-w-md mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="card bg-gradient-to-br from-ninja-orange/10 to-transparent border-ninja-orange/30"
          >
            <Zap className="w-12 h-12 text-ninja-orange mx-auto mb-4" />
            <h2 className="text-2xl font-bold mb-2">
              Mau Explore Lebih Lanjut?
            </h2>
            <p className="text-ninja-text-dim mb-6">
              Chat sama Abang Ninja buat dapetin advice yang lebih spesifik. 
              Tanya apa aja soal karir lo.
            </p>
            <div className="text-3xl font-bold text-ninja-orange mb-4">
              Rp 6.969
            </div>
            <p className="text-ninja-text-dim text-sm mb-6">
              25 pesan • Lebih murah dari kopi susu
            </p>
            <button
              onClick={handleContinueChat}
              className="btn-primary w-full flex items-center justify-center gap-2"
            >
              <MessageCircle className="w-5 h-5" />
              {hasPaid ? 'Lanjut Chat' : 'Bayar & Chat'}
              <ChevronRight className="w-5 h-5" />
            </button>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="px-4 py-8 text-center text-ninja-text-dim text-sm">
        <p>
          Ada pertanyaan? DM kami di{' '}
          <a href="#" className="text-ninja-orange hover:underline">
            @jalanninjaku
          </a>
        </p>
      </footer>
    </div>
  );
}
