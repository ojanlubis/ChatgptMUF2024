import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        // Naruto orange palette
        ninja: {
          orange: "#FF6B00",
          "orange-light": "#FF8C3A", 
          "orange-dark": "#E05A00",
          black: "#0A0A0B",
          dark: "#141416",
          gray: "#1E1E22",
          "gray-light": "#2A2A30",
          text: "#E8E8E8",
          "text-dim": "#9A9A9A",
        },
        // Rank colors
        rank: {
          genin: "#4ADE80",      // green - beginner
          chunin: "#3B82F6",     // blue - intermediate  
          jonin: "#A855F7",      // purple - advanced
          hokage: "#FF6B00",     // orange - master
        }
      },
      fontFamily: {
        display: ["var(--font-display)", "system-ui", "sans-serif"],
        body: ["var(--font-body)", "system-ui", "sans-serif"],
      },
      animation: {
        "fade-in": "fadeIn 0.5s ease-out",
        "slide-up": "slideUp 0.5s ease-out",
        "slide-in-right": "slideInRight 0.3s ease-out",
        "pulse-orange": "pulseOrange 2s infinite",
        "float": "float 3s ease-in-out infinite",
      },
      keyframes: {
        fadeIn: {
          "0%": { opacity: "0" },
          "100%": { opacity: "1" },
        },
        slideUp: {
          "0%": { opacity: "0", transform: "translateY(20px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
        slideInRight: {
          "0%": { opacity: "0", transform: "translateX(20px)" },
          "100%": { opacity: "1", transform: "translateX(0)" },
        },
        pulseOrange: {
          "0%, 100%": { boxShadow: "0 0 0 0 rgba(255, 107, 0, 0.4)" },
          "50%": { boxShadow: "0 0 0 15px rgba(255, 107, 0, 0)" },
        },
        float: {
          "0%, 100%": { transform: "translateY(0)" },
          "50%": { transform: "translateY(-10px)" },
        },
      },
      backgroundImage: {
        "gradient-radial": "radial-gradient(var(--tw-gradient-stops))",
        "ninja-pattern": "url('/ninja-pattern.svg')",
      },
    },
  },
  plugins: [],
};

export default config;
