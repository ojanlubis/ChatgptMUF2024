import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { nanoid } from 'nanoid';
import type { AssessmentResult } from './claude';

// =============================================
// SESSION STORE
// Manages user session, assessment progress,
// and payment state
// =============================================

interface SessionState {
  // Session
  sessionId: string | null;
  userId: string | null;
  
  // Assessment
  assessmentId: string | null;
  currentQuestion: number;
  answers: Record<number, string | number>;
  assessmentResult: AssessmentResult | null;
  isAssessmentComplete: boolean;
  
  // Payment
  hasPaid: boolean;
  paymentId: string | null;
  
  // Chat
  chatSessionId: string | null;
  messageCount: number;
  messageLimit: number;
  
  // Actions
  initSession: () => void;
  setUserId: (userId: string) => void;
  setAssessmentId: (assessmentId: string) => void;
  setAnswer: (questionId: number, answer: string | number) => void;
  nextQuestion: () => void;
  prevQuestion: () => void;
  setAssessmentResult: (result: AssessmentResult) => void;
  completeAssessment: () => void;
  setPaid: (paymentId: string) => void;
  setChatSession: (sessionId: string, limit: number) => void;
  incrementMessageCount: () => void;
  reset: () => void;
}

export const useSessionStore = create<SessionState>()(
  persist(
    (set, get) => ({
      // Initial state
      sessionId: null,
      userId: null,
      assessmentId: null,
      currentQuestion: 1,
      answers: {},
      assessmentResult: null,
      isAssessmentComplete: false,
      hasPaid: false,
      paymentId: null,
      chatSessionId: null,
      messageCount: 0,
      messageLimit: 25,

      // Actions
      initSession: () => {
        const current = get();
        if (!current.sessionId) {
          set({ sessionId: nanoid() });
        }
      },

      setUserId: (userId: string) => set({ userId }),

      setAssessmentId: (assessmentId: string) => set({ assessmentId }),

      setAnswer: (questionId: number, answer: string | number) => {
        set((state) => ({
          answers: { ...state.answers, [questionId]: answer },
        }));
      },

      nextQuestion: () => {
        set((state) => ({
          currentQuestion: Math.min(state.currentQuestion + 1, 10),
        }));
      },

      prevQuestion: () => {
        set((state) => ({
          currentQuestion: Math.max(state.currentQuestion - 1, 1),
        }));
      },

      setAssessmentResult: (result: AssessmentResult) => {
        set({ assessmentResult: result });
      },

      completeAssessment: () => {
        set({ isAssessmentComplete: true });
      },

      setPaid: (paymentId: string) => {
        set({ hasPaid: true, paymentId });
      },

      setChatSession: (sessionId: string, limit: number) => {
        set({ chatSessionId: sessionId, messageLimit: limit, messageCount: 0 });
      },

      incrementMessageCount: () => {
        set((state) => ({ messageCount: state.messageCount + 1 }));
      },

      reset: () => {
        set({
          sessionId: nanoid(),
          userId: null,
          assessmentId: null,
          currentQuestion: 1,
          answers: {},
          assessmentResult: null,
          isAssessmentComplete: false,
          hasPaid: false,
          paymentId: null,
          chatSessionId: null,
          messageCount: 0,
          messageLimit: 25,
        });
      },
    }),
    {
      name: 'jalanninjaku-session',
      partialize: (state) => ({
        sessionId: state.sessionId,
        userId: state.userId,
        assessmentId: state.assessmentId,
        answers: state.answers,
        assessmentResult: state.assessmentResult,
        isAssessmentComplete: state.isAssessmentComplete,
        hasPaid: state.hasPaid,
        paymentId: state.paymentId,
        chatSessionId: state.chatSessionId,
        messageCount: state.messageCount,
      }),
    }
  )
);

// Helper hooks
export const useCurrentQuestion = () => useSessionStore((s) => s.currentQuestion);
export const useAnswers = () => useSessionStore((s) => s.answers);
export const useAssessmentResult = () => useSessionStore((s) => s.assessmentResult);
export const useHasPaid = () => useSessionStore((s) => s.hasPaid);
export const useCanChat = () => {
  const store = useSessionStore();
  return store.hasPaid && store.messageCount < store.messageLimit;
};
export const useRemainingMessages = () => {
  const store = useSessionStore();
  return store.messageLimit - store.messageCount;
};
