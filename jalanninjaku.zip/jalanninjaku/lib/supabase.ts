import { createClient } from '@supabase/supabase-js';

// Types for our database
export type Database = {
  public: {
    Tables: {
      users: {
        Row: {
          id: string;
          session_id: string;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          session_id: string;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          session_id?: string;
          updated_at?: string;
        };
      };
      assessments: {
        Row: {
          id: string;
          user_id: string;
          answers: any;
          ninja_type: string | null;
          ninja_rank: string;
          character_match: string | null;
          personality_summary: string | null;
          strengths: any;
          career_matches: any;
          growth_area: string | null;
          result_card_url: string | null;
          completed_at: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          answers: any;
          ninja_type?: string;
          ninja_rank?: string;
          character_match?: string;
          personality_summary?: string;
          strengths?: any;
          career_matches?: any;
          growth_area?: string;
          result_card_url?: string;
          completed_at?: string;
        };
        Update: Partial<Database['public']['Tables']['assessments']['Insert']>;
      };
      payments: {
        Row: {
          id: string;
          user_id: string;
          assessment_id: string | null;
          order_id: string;
          transaction_id: string | null;
          payment_type: string | null;
          gross_amount: number;
          status: string;
          paid_at: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          assessment_id?: string;
          order_id: string;
          transaction_id?: string;
          payment_type?: string;
          gross_amount: number;
          status?: string;
          paid_at?: string;
        };
        Update: Partial<Database['public']['Tables']['payments']['Insert']>;
      };
      chat_sessions: {
        Row: {
          id: string;
          user_id: string;
          assessment_id: string | null;
          payment_id: string | null;
          message_count: number;
          message_limit: number;
          is_active: boolean;
          started_at: string;
          ended_at: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          assessment_id?: string;
          payment_id?: string;
          message_count?: number;
          message_limit?: number;
          is_active?: boolean;
        };
        Update: Partial<Database['public']['Tables']['chat_sessions']['Insert']>;
      };
      chat_messages: {
        Row: {
          id: string;
          session_id: string;
          role: 'user' | 'assistant';
          content: string;
          tokens_used: number | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          session_id: string;
          role: 'user' | 'assistant';
          content: string;
          tokens_used?: number;
        };
        Update: Partial<Database['public']['Tables']['chat_messages']['Insert']>;
      };
      analytics_events: {
        Row: {
          id: string;
          user_id: string | null;
          event_name: string;
          event_data: any;
          page_url: string | null;
          referrer: string | null;
          user_agent: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          user_id?: string;
          event_name: string;
          event_data?: any;
          page_url?: string;
          referrer?: string;
          user_agent?: string;
        };
        Update: Partial<Database['public']['Tables']['analytics_events']['Insert']>;
      };
    };
  };
};

// Client-side Supabase client (uses anon key)
export const createBrowserClient = () => {
  return createClient<Database>(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  );
};

// Server-side Supabase client (uses service role key)
export const createServerClient = () => {
  return createClient<Database>(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    {
      auth: {
        autoRefreshToken: false,
        persistSession: false,
      },
    }
  );
};

// Singleton for browser client
let browserClient: ReturnType<typeof createBrowserClient> | null = null;

export const getSupabase = () => {
  if (typeof window === 'undefined') {
    // Server-side: always create new client
    return createServerClient();
  }
  
  // Client-side: reuse client
  if (!browserClient) {
    browserClient = createBrowserClient();
  }
  return browserClient;
};
