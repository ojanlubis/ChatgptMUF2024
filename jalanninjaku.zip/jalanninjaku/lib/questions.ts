// =============================================
// ASSESSMENT QUESTIONS
// 10 questions designed to understand:
// - Work style preferences
// - Strengths & natural tendencies
// - Values & motivations
// - Career stage & goals
// =============================================

export type Question = {
  id: number;
  question: string;
  subtitle?: string;
  type: 'choice' | 'scale' | 'text';
  options?: Array<{
    value: string;
    label: string;
    emoji?: string;
  }>;
  scaleLabels?: {
    left: string;
    right: string;
  };
};

export const assessmentQuestions: Question[] = [
  {
    id: 1,
    question: "Lo lagi di stage karir yang mana sekarang?",
    subtitle: "Biar gue tau context lo",
    type: 'choice',
    options: [
      { value: 'student', label: 'Masih kuliah/sekolah', emoji: '📚' },
      { value: 'fresh_grad', label: 'Fresh graduate (<1 tahun)', emoji: '🎓' },
      { value: 'early', label: 'Udah kerja 1-3 tahun', emoji: '💼' },
      { value: 'mid', label: 'Udah kerja 3-7 tahun', emoji: '📈' },
      { value: 'senior', label: 'Udah kerja 7+ tahun', emoji: '🏆' },
    ],
  },
  {
    id: 2,
    question: "Kalo dikasih project baru, lo biasanya gimana?",
    subtitle: "Ga ada jawaban yang salah ya",
    type: 'choice',
    options: [
      { value: 'plan_first', label: 'Planning dulu sampe detail baru eksekusi', emoji: '📋' },
      { value: 'dive_in', label: 'Langsung gas, sambil jalan dipikir', emoji: '🚀' },
      { value: 'research', label: 'Research dulu, liat orang lain gimana', emoji: '🔍' },
      { value: 'delegate', label: 'Ngobrol sama tim dulu, bagi tugas', emoji: '🤝' },
    ],
  },
  {
    id: 3,
    question: "Lo lebih enjoy kerja...",
    type: 'scale',
    scaleLabels: {
      left: 'Sendiri, fokus deep work',
      right: 'Sama tim, kolaborasi terus',
    },
  },
  {
    id: 4,
    question: "Kalo ada masalah di kerjaan, lo biasanya?",
    type: 'choice',
    options: [
      { value: 'analyze', label: 'Analisis sampe ketemu root cause-nya', emoji: '🧠' },
      { value: 'ask', label: 'Tanya orang yang lebih experienced', emoji: '💬' },
      { value: 'creative', label: 'Coba cara baru yang belum pernah dicoba', emoji: '💡' },
      { value: 'systematic', label: 'Ikutin SOP atau best practice yang ada', emoji: '📖' },
    ],
  },
  {
    id: 5,
    question: "Yang bikin lo semangat kerja itu apa sih?",
    subtitle: "Pilih yang paling relate",
    type: 'choice',
    options: [
      { value: 'money', label: 'Gaji & financial security', emoji: '💰' },
      { value: 'impact', label: 'Ngerasa kerjaan gue meaningful', emoji: '🌟' },
      { value: 'growth', label: 'Belajar skill baru terus', emoji: '📈' },
      { value: 'recognition', label: 'Diapresiasi sama orang lain', emoji: '🏅' },
      { value: 'freedom', label: 'Kebebasan & work-life balance', emoji: '🏖️' },
    ],
  },
  {
    id: 6,
    question: "Lo lebih suka hasil kerja yang...",
    type: 'scale',
    scaleLabels: {
      left: 'Tangible & bisa diliat langsung',
      right: 'Abstract & long-term impact',
    },
  },
  {
    id: 7,
    question: "Menurut orang-orang sekitar lo, lo itu orangnya?",
    subtitle: "Pilih 2 yang paling sering didenger",
    type: 'choice',
    options: [
      { value: 'reliable', label: 'Bisa diandalkan', emoji: '🤝' },
      { value: 'creative', label: 'Kreatif & ide-idenya unik', emoji: '🎨' },
      { value: 'logical', label: 'Logis & analytical', emoji: '🧮' },
      { value: 'leader', label: 'Natural leader', emoji: '👑' },
      { value: 'empathetic', label: 'Pengertian & good listener', emoji: '💚' },
      { value: 'driven', label: 'Ambisius & hardworking', emoji: '🔥' },
    ],
  },
  {
    id: 8,
    question: "Situasi kerja yang bikin lo stress itu?",
    subtitle: "Pilih yang paling ga nyaman",
    type: 'choice',
    options: [
      { value: 'ambiguity', label: 'Ga jelas goal-nya apa', emoji: '❓' },
      { value: 'conflict', label: 'Drama & konflik sama orang', emoji: '😤' },
      { value: 'routine', label: 'Kerjaan monoton & boring', emoji: '😴' },
      { value: 'pressure', label: 'Deadline ketat & pressure tinggi', emoji: '⏰' },
      { value: 'isolation', label: 'Kerja sendirian terus', emoji: '🏝️' },
    ],
  },
  {
    id: 9,
    question: "5 tahun lagi, lo pengen jadi?",
    subtitle: "Dream scenario",
    type: 'choice',
    options: [
      { value: 'expert', label: 'Expert di bidang gue', emoji: '🎯' },
      { value: 'manager', label: 'Lead tim / manager', emoji: '👔' },
      { value: 'founder', label: 'Punya bisnis sendiri', emoji: '🚀' },
      { value: 'freelance', label: 'Freelancer / independent', emoji: '🏖️' },
      { value: 'explore', label: 'Masih explore, belum fix', emoji: '🗺️' },
    ],
  },
  {
    id: 10,
    question: "Apa yang lagi jadi concern utama karir lo sekarang?",
    subtitle: "Cerita bebas, gue dengerin",
    type: 'text',
  },
];

// Helper to get question by ID
export function getQuestion(id: number): Question | undefined {
  return assessmentQuestions.find((q) => q.id === id);
}

// Helper to format answers for Claude
export function formatAnswersForAnalysis(
  answers: Record<number, string | number>
): Array<{ question: string; answer: string }> {
  return assessmentQuestions.map((q) => {
    let answerText = String(answers[q.id] || 'Tidak dijawab');

    // Convert scale value to descriptive text
    if (q.type === 'scale' && q.scaleLabels) {
      const value = Number(answers[q.id]);
      if (value <= 2) answerText = `Lebih ke: ${q.scaleLabels.left}`;
      else if (value >= 4) answerText = `Lebih ke: ${q.scaleLabels.right}`;
      else answerText = 'Di tengah-tengah';
    }

    // Convert choice value to label
    if (q.type === 'choice' && q.options) {
      const option = q.options.find((o) => o.value === answers[q.id]);
      if (option) answerText = option.label;
    }

    return {
      question: q.question,
      answer: answerText,
    };
  });
}
