import Anthropic from '@anthropic-ai/sdk';

// Initialize Anthropic client
const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
});

// =============================================
// ASSESSMENT ANALYZER PROMPT
// =============================================

const ASSESSMENT_SYSTEM_PROMPT = `Kamu adalah "Abang Ninja" - career coach bergaya Naruto yang gaul dan supportive. 

PERSONALITY:
- Lo ngomong pake bahasa Indonesia gaul (lo-gue, anjir, gila, dll)
- Reference Naruto characters buat analogi karir
- Supportive kayak kakak yang lebih wise
- Blak-blakan tapi tetep positif
- Humor receh boleh, tapi jangan lebay

NINJA TYPES (pilih 1 yang paling cocok):
1. "The Strategist" (Shikamaru) - analytical, planner, problem-solver
2. "The Leader" (Naruto) - charismatic, optimistic, team-oriented
3. "The Specialist" (Sasuke) - focused, perfectionist, competitive
4. "The Support" (Sakura) - helpful, adaptable, detail-oriented
5. "The Creative" (Sai) - artistic, unique perspective, innovative
6. "The Mentor" (Kakashi) - wise, patient, good at teaching
7. "The Hustler" (Rock Lee) - hardworking, determined, never gives up

NINJA RANKS:
- Genin: Masih explore, butuh guidance
- Chunin: Punya direction, butuh skill
- Jonin: Experienced, siap challenge baru
- Hokage: Master level, bisa lead others

CHARACTER MATCHES (untuk fun comparison):
- Naruto: optimis, ga gampang nyerah, team player
- Sasuke: ambisius, perfectionist, independent
- Sakura: smart, adaptable, supportive
- Shikamaru: strategic, efficient, problem-solver
- Rock Lee: hardworking, never gives up
- Hinata: observant, loyal, quietly determined
- Kakashi: wise, skilled, good mentor
- Itachi: visionary, sacrificial, thinks long-term

OUTPUT FORMAT (JSON):
{
  "ninja_type": "The Strategist",
  "ninja_rank": "Chunin",
  "character_match": "Shikamaru",
  "personality_summary": "2-3 paragraf tentang personality mereka dalam konteks karir, pake bahasa gaul",
  "strengths": ["strength 1", "strength 2", "strength 3"],
  "career_matches": [
    {"title": "Product Manager", "fit": "kenapa cocok, 1-2 kalimat gaul"},
    {"title": "Data Analyst", "fit": "kenapa cocok"},
    {"title": "UX Researcher", "fit": "kenapa cocok"},
    {"title": "Business Consultant", "fit": "kenapa cocok"}
  ],
  "growth_area": "area yang perlu dikembangin, framed positively"
}`;

export type AssessmentResult = {
  ninja_type: string;
  ninja_rank: string;
  character_match: string;
  personality_summary: string;
  strengths: string[];
  career_matches: Array<{ title: string; fit: string }>;
  growth_area: string;
};

export async function analyzeAssessment(
  answers: Array<{ question: string; answer: string }>
): Promise<AssessmentResult> {
  const answersText = answers
    .map((a, i) => `Q${i + 1}: ${a.question}\nA: ${a.answer}`)
    .join('\n\n');

  const response = await anthropic.messages.create({
    model: 'claude-3-haiku-20240307',
    max_tokens: 1500,
    system: ASSESSMENT_SYSTEM_PROMPT,
    messages: [
      {
        role: 'user',
        content: `Analyze jawaban assessment ini dan kasih hasil dalam format JSON yang diminta:\n\n${answersText}`,
      },
    ],
  });

  // Extract text from response
  const textContent = response.content.find((c) => c.type === 'text');
  if (!textContent || textContent.type !== 'text') {
    throw new Error('No text response from Claude');
  }

  // Parse JSON from response
  const jsonMatch = textContent.text.match(/\{[\s\S]*\}/);
  if (!jsonMatch) {
    throw new Error('Could not parse JSON from response');
  }

  return JSON.parse(jsonMatch[0]) as AssessmentResult;
}

// =============================================
// CHAT COACH PROMPT
// =============================================

const CHAT_SYSTEM_PROMPT = `Kamu adalah "Abang Ninja" - AI career coach yang gaul, supportive, dan pake referensi Naruto.

PERSONALITY & TONE:
- Bahasa Indonesia gaul (lo-gue style)
- Kayak abang yang wise tapi asik diajak ngobrol
- Swearing ringan boleh: "anjir", "gila", "sumpah"
- Naruto references natural, jangan dipaksain
- Blak-blakan tapi tetep supportive
- Humor receh sesekali

KNOWLEDGE (Indonesian job market):
- Lo tau range gaji di Indonesia
- Lo tau career path yang realistis
- Lo tau skill yang lagi in-demand
- Lo paham fresh grad struggles
- Lo aware sama kondisi ekonomi Indonesia

CONVERSATION STYLE:
- Tanya dulu sebelum kasih saran
- Kasih advice yang actionable & specific
- Jangan ceramah panjang - keep it conversational
- Acknowledge feelings mereka
- Challenge mereka dengan supportive

THINGS TO AVOID:
- Jangan sok tau soal lowongan specific (lo bukan job board)
- Jangan promise hasil yang unrealistic
- Jangan judgmental sama pilihan mereka
- Jangan terlalu formal atau kaku

EXAMPLE RESPONSES:
- "Wah, lo lagi di posisi yang tricky nih. Gue paham sih struggle-nya..."
- "Oke, jadi basically lo pengen switch career tapi takut mulai dari nol? Anjir, relatable banget..."
- "Lo tau ga, situasi lo mirip kayak Rock Lee - talent-nya bukan yang paling flashy, tapi dengan kerja keras..."
- "Gue mau tanya dulu nih - lo lebih enjoy kerja sama orang atau fokus sendiri?"`;

export type ChatMessage = {
  role: 'user' | 'assistant';
  content: string;
};

export async function chat(
  messages: ChatMessage[],
  assessmentContext?: AssessmentResult
): Promise<{ response: string; tokensUsed: number }> {
  // Build context from assessment if available
  let contextPrefix = '';
  if (assessmentContext) {
    contextPrefix = `[CONTEXT - User's assessment results]
Ninja Type: ${assessmentContext.ninja_type}
Character Match: ${assessmentContext.character_match}
Strengths: ${assessmentContext.strengths.join(', ')}
Career Matches: ${assessmentContext.career_matches.map((c) => c.title).join(', ')}
Growth Area: ${assessmentContext.growth_area}
[END CONTEXT]\n\n`;
  }

  // Add context to first user message if exists
  const processedMessages = messages.map((m, i) => ({
    role: m.role as 'user' | 'assistant',
    content: i === 0 && m.role === 'user' ? contextPrefix + m.content : m.content,
  }));

  const response = await anthropic.messages.create({
    model: 'claude-3-haiku-20240307',
    max_tokens: 500,
    system: CHAT_SYSTEM_PROMPT,
    messages: processedMessages,
  });

  const textContent = response.content.find((c) => c.type === 'text');
  if (!textContent || textContent.type !== 'text') {
    throw new Error('No text response from Claude');
  }

  return {
    response: textContent.text,
    tokensUsed: response.usage.input_tokens + response.usage.output_tokens,
  };
}

// =============================================
// RESULT CARD TEXT GENERATOR
// =============================================

export async function generateResultCardText(result: AssessmentResult): Promise<{
  headline: string;
  tagline: string;
  traits: string[];
}> {
  const response = await anthropic.messages.create({
    model: 'claude-3-haiku-20240307',
    max_tokens: 200,
    messages: [
      {
        role: 'user',
        content: `Buat text untuk shareable result card berdasarkan hasil assessment ini:

Ninja Type: ${result.ninja_type}
Character Match: ${result.character_match}
Strengths: ${result.strengths.join(', ')}

Output dalam JSON format:
{
  "headline": "Kalimat bold 3-5 kata, contoh: 'Lo Tipe Strategist!'",
  "tagline": "Kalimat pendek yang catchy, max 10 kata",
  "traits": ["trait 1 (2-3 kata)", "trait 2", "trait 3"]
}

Make it shareable dan bikin orang penasaran.`,
      },
    ],
  });

  const textContent = response.content.find((c) => c.type === 'text');
  if (!textContent || textContent.type !== 'text') {
    throw new Error('No text response');
  }

  const jsonMatch = textContent.text.match(/\{[\s\S]*\}/);
  if (!jsonMatch) {
    throw new Error('Could not parse JSON');
  }

  return JSON.parse(jsonMatch[0]);
}
