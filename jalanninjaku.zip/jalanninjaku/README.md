# 🍥 JalanNinjaku.id

AI Career Coach bergaya Naruto untuk shinobi Indonesia.

## Tech Stack

- **Frontend**: Next.js 14, Tailwind CSS, Framer Motion
- **Backend**: Next.js API Routes
- **Database**: Supabase (PostgreSQL)
- **AI**: Claude API (Haiku)
- **Payments**: Midtrans

## Setup

### 1. Clone & Install

```bash
git clone <repo>
cd jalanninjaku
npm install
```

### 2. Create Accounts

You need to create accounts at:

1. **Supabase** (https://supabase.com)
   - Create a new project
   - Run the SQL in `supabase-schema.sql` in the SQL Editor
   - Get your project URL and keys

2. **Anthropic** (https://console.anthropic.com)
   - Create an API key
   - Add credits to your account

3. **Midtrans** (https://dashboard.midtrans.com)
   - Register for a sandbox account
   - Get your server and client keys

### 3. Environment Variables

Copy `.env.example` to `.env.local` and fill in:

```bash
cp .env.example .env.local
```

Edit `.env.local`:

```env
# Supabase
NEXT_PUBLIC_SUPABASE_URL=https://xxxxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJxxxxx
SUPABASE_SERVICE_ROLE_KEY=eyJxxxxx

# Anthropic
ANTHROPIC_API_KEY=sk-ant-xxxxx

# Midtrans (Sandbox)
MIDTRANS_SERVER_KEY=SB-Mid-server-xxxxx
NEXT_PUBLIC_MIDTRANS_CLIENT_KEY=SB-Mid-client-xxxxx
MIDTRANS_IS_PRODUCTION=false

# App
NEXT_PUBLIC_APP_URL=http://localhost:3000
NEXT_PUBLIC_PRICE_IDR=6969
```

### 4. Run Development Server

```bash
npm run dev
```

Visit http://localhost:3000

## Project Structure

```
jalanninjaku/
├── app/
│   ├── api/
│   │   ├── assessment/submit/    # Assessment analysis
│   │   ├── chat/                  # Chat with AI
│   │   ├── payment/               # Midtrans integration
│   │   └── analytics/             # Event tracking
│   ├── assessment/                # Assessment flow
│   ├── result/                    # Results page
│   ├── bayar/                     # Payment page
│   ├── chat/                      # Chat interface
│   ├── globals.css                # Global styles
│   ├── layout.tsx                 # Root layout
│   └── page.tsx                   # Landing page
├── components/                    # Reusable components
├── lib/
│   ├── claude.ts                  # Claude API integration
│   ├── questions.ts               # Assessment questions
│   ├── store.ts                   # Zustand state store
│   └── supabase.ts                # Supabase client
├── supabase-schema.sql            # Database schema
└── .env.example                   # Environment template
```

## Deployment

### Vercel (Recommended)

1. Push to GitHub
2. Connect repo to Vercel
3. Add environment variables in Vercel dashboard
4. Deploy

### Database Migration

Run `supabase-schema.sql` in your production Supabase project.

## Costs

- **Claude API (Haiku)**: ~$0.25/1M input, ~$1.25/1M output tokens
- **Supabase**: Free tier sufficient for MVP
- **Vercel**: Free tier sufficient for MVP
- **Midtrans**: 2.9% + Rp 2,000 per transaction

Estimated cost per paid user: ~Rp 1,500-2,500 (API + payment fees)

## TODO

- [ ] Add rate limiting
- [ ] Add error boundaries
- [ ] Add email notifications
- [ ] Add admin dashboard
- [ ] Add A/B testing for pricing
- [ ] Add referral system

## License

MIT
