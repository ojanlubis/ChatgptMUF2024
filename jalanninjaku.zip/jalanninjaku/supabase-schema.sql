-- =============================================
-- JALANNINJAKU.ID DATABASE SCHEMA
-- Run this in Supabase SQL Editor
-- =============================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- =============================================
-- USERS TABLE (anonymous sessions)
-- =============================================
CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  session_id TEXT UNIQUE NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Index for session lookups
CREATE INDEX idx_users_session ON users(session_id);

-- =============================================
-- ASSESSMENTS TABLE
-- =============================================
CREATE TABLE assessments (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  
  -- Raw answers (JSON array)
  answers JSONB NOT NULL,
  
  -- Computed results
  ninja_type TEXT, -- e.g., "Strategist", "Leader", "Creator"
  ninja_rank TEXT DEFAULT 'Genin', -- Genin, Chunin, Jonin, Hokage
  character_match TEXT, -- e.g., "Shikamaru", "Naruto"
  
  -- AI-generated content
  personality_summary TEXT,
  strengths JSONB, -- array of 3 strengths
  career_matches JSONB, -- array of 4 career recommendations
  growth_area TEXT,
  
  -- Result card data
  result_card_url TEXT,
  
  -- Metadata
  completed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Index for user lookups
CREATE INDEX idx_assessments_user ON assessments(user_id);

-- =============================================
-- PAYMENTS TABLE
-- =============================================
CREATE TABLE payments (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  assessment_id UUID REFERENCES assessments(id) ON DELETE SET NULL,
  
  -- Midtrans data
  order_id TEXT UNIQUE NOT NULL,
  transaction_id TEXT,
  payment_type TEXT, -- qris, gopay, etc.
  
  -- Amount
  gross_amount INTEGER NOT NULL, -- in IDR (6969)
  
  -- Status
  status TEXT DEFAULT 'pending', -- pending, success, failed, expired
  
  -- Timestamps
  paid_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes
CREATE INDEX idx_payments_user ON payments(user_id);
CREATE INDEX idx_payments_order ON payments(order_id);
CREATE INDEX idx_payments_status ON payments(status);

-- =============================================
-- CHAT SESSIONS TABLE
-- =============================================
CREATE TABLE chat_sessions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  assessment_id UUID REFERENCES assessments(id) ON DELETE SET NULL,
  payment_id UUID REFERENCES payments(id) ON DELETE SET NULL,
  
  -- Session limits
  message_count INTEGER DEFAULT 0,
  message_limit INTEGER DEFAULT 25,
  
  -- Status
  is_active BOOLEAN DEFAULT true,
  
  -- Timestamps
  started_at TIMESTAMPTZ DEFAULT NOW(),
  ended_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Index for user lookups
CREATE INDEX idx_chat_sessions_user ON chat_sessions(user_id);

-- =============================================
-- CHAT MESSAGES TABLE
-- =============================================
CREATE TABLE chat_messages (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  session_id UUID REFERENCES chat_sessions(id) ON DELETE CASCADE,
  
  -- Message content
  role TEXT NOT NULL, -- 'user' or 'assistant'
  content TEXT NOT NULL,
  
  -- Token tracking (for cost analysis)
  tokens_used INTEGER,
  
  -- Timestamp
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Index for session lookups
CREATE INDEX idx_chat_messages_session ON chat_messages(session_id);
CREATE INDEX idx_chat_messages_created ON chat_messages(created_at);

-- =============================================
-- ANALYTICS EVENTS TABLE
-- =============================================
CREATE TABLE analytics_events (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES users(id) ON DELETE SET NULL,
  
  -- Event data
  event_name TEXT NOT NULL, -- 'assessment_started', 'assessment_completed', 'payment_initiated', etc.
  event_data JSONB,
  
  -- Context
  page_url TEXT,
  referrer TEXT,
  user_agent TEXT,
  
  -- Timestamp
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes for analytics queries
CREATE INDEX idx_analytics_event ON analytics_events(event_name);
CREATE INDEX idx_analytics_created ON analytics_events(created_at);
CREATE INDEX idx_analytics_user ON analytics_events(user_id);

-- =============================================
-- USEFUL VIEWS
-- =============================================

-- Funnel metrics view
CREATE VIEW funnel_metrics AS
SELECT 
  DATE(created_at) as date,
  COUNT(*) FILTER (WHERE event_name = 'assessment_started') as assessments_started,
  COUNT(*) FILTER (WHERE event_name = 'assessment_completed') as assessments_completed,
  COUNT(*) FILTER (WHERE event_name = 'payment_initiated') as payments_initiated,
  COUNT(*) FILTER (WHERE event_name = 'payment_success') as payments_success,
  COUNT(*) FILTER (WHERE event_name = 'chat_started') as chats_started,
  COUNT(*) FILTER (WHERE event_name = 'result_shared') as results_shared
FROM analytics_events
GROUP BY DATE(created_at)
ORDER BY date DESC;

-- =============================================
-- ROW LEVEL SECURITY (RLS)
-- =============================================

-- Enable RLS on all tables
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE assessments ENABLE ROW LEVEL SECURITY;
ALTER TABLE payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE chat_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE chat_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE analytics_events ENABLE ROW LEVEL SECURITY;

-- For now, allow all operations (we'll use service role key)
-- In production, you'd want more restrictive policies

CREATE POLICY "Allow all for service role" ON users FOR ALL USING (true);
CREATE POLICY "Allow all for service role" ON assessments FOR ALL USING (true);
CREATE POLICY "Allow all for service role" ON payments FOR ALL USING (true);
CREATE POLICY "Allow all for service role" ON chat_sessions FOR ALL USING (true);
CREATE POLICY "Allow all for service role" ON chat_messages FOR ALL USING (true);
CREATE POLICY "Allow all for service role" ON analytics_events FOR ALL USING (true);

-- =============================================
-- FUNCTIONS
-- =============================================

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Apply trigger to relevant tables
CREATE TRIGGER update_users_updated_at
  BEFORE UPDATE ON users
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER update_payments_updated_at
  BEFORE UPDATE ON payments
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();
